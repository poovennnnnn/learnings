package com.pooven.exception;

public class InSufficientAmmountException extends Exception {

	private static final long serialVersionUID = 1L;

	public InSufficientAmmountException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
