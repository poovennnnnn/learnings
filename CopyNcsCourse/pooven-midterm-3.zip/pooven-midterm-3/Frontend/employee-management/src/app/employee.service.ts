import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  employeeUrl: string = `http://localhost:8080/employee`;
  constructor(private http: HttpClient) {}

  addEmployee(employee?: Employee): Observable<Object> {
    return this.http.post(this.employeeUrl, employee);
  }
  updateEmployee(employee?: Employee): Observable<Object> {
    return this.http.put(this.employeeUrl, employee);
  }

  findById(id?: number) {
    return this.http.get(this.employeeUrl + `/${id}`);
  }

  findAllEmployee(): Observable<Object> {
    return this.http.get(this.employeeUrl);
  }

  deleteById(id?: number): Observable<Object> {
    return this.http.delete(this.employeeUrl + `/${id}`);
  }
}
