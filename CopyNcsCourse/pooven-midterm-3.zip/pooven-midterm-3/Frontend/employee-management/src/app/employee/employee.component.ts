import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { lastValueFrom } from 'rxjs';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
})
export class EmployeeComponent implements OnInit {
  employees?: Employee[];
  employee?: Employee = new Employee();
  empName?: String;
  isUpdate: boolean = false;
  showForm: boolean = false;
  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void {
    this.getAllEmployee();
  }

  async onSubmit(empForm: NgForm) {
    this.isUpdate = false;
    this.showForm = false;
    await lastValueFrom(this.employeeService.addEmployee(this.employee));
    this.isUpdate = false;
    empForm.reset();
    this.employee = new Employee();
    this.getAllEmployee();
  }

  async handleEdit(id?: number) {
    this.showForm = true;
    this.isUpdate = true;
    this.employee = await lastValueFrom(this.employeeService.findById(id));
  }

  addUpdateBtn() {
    return {
      btn: true,
      'btn-warning': this.isUpdate,
      'btn-primary': !this.isUpdate,
      'm-2': true,
      'p-2': true,
    };
  }

  async search() {
    console.log(this.empName);
    console.log('clicked');
    if ((this.empName = '')) {
      this.ngOnInit();
    } else {
      this.employees = this.employees?.filter(
        (res) => res.empName == this.empName
      );
      console.log(
        this.employees?.filter((res) => {
          return res.empName
            ?.toLocaleLowerCase()
            .match(this.empName!.toLocaleLowerCase());
        })
      );
    }
  }

  async handleDelete(empId?: number) {
    let x = await lastValueFrom(this.employeeService.deleteById(empId));
    this.getAllEmployee();
  }

  handleAddEmployee() {
    this.showForm = true;
    this.isUpdate = false;
  }

  async getAllEmployee() {
    this.employees = (await lastValueFrom(
      this.employeeService.findAllEmployee()
    )) as Employee[];
  }
}
