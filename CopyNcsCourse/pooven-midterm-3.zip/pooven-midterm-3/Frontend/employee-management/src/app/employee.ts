export class Employee {
  constructor(
    public empId?: number,
    public empName?: string,
    public job?: string,
    public salary?: number
  ) {}
}
